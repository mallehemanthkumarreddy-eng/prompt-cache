// constants/prismConfig.ts
// PRISM v2.0 - Configuration Constants for Scatter AI

// ============================================
// SPECTRUM - Available Models
// ============================================
export const SPECTRUM = {
  'gemini-2.0-flash': {
    provider: 'Google',
    role: 'orchestrator',
    bestFor: ['routing', 'multimodal', 'speed'],
    speedTier: 3,
    tokenLimit: 32768,
    icon: '⚡',
  },
  'gemini-3.0-pro': {
    provider: 'Google',
    role: 'analyst',
    bestFor: ['complex-analysis', 'long-context', 'research'],
    speedTier: 2,
    tokenLimit: 128000,
    icon: '🔬',
  },
  'claude-3.5-sonnet': {
    provider: 'Anthropic',
    role: 'writer',
    bestFor: ['writing', 'nuance', 'safety', 'creative'],
    speedTier: 2,
    tokenLimit: 200000,
    icon: '✍️',
  },
  'deepseek-r1': {
    provider: 'DeepSeek',
    role: 'reasoner',
    bestFor: ['reasoning', 'math', 'logic', 'chain-of-thought'],
    speedTier: 2,
    tokenLimit: 64000,
    icon: '🧠',
  },
  'llama-3.3-70b': {
    provider: 'Meta (Groq)',
    role: 'speed-general',
    bestFor: ['general-chat', 'summaries', 'speed'],
    speedTier: 3,
    tokenLimit: 8192,
    icon: '🦙',
  },
  'qwen-2.5-coder': {
    provider: 'Alibaba',
    role: 'coder',
    bestFor: ['code-generation', 'debugging', 'refactoring'],
    speedTier: 2,
    tokenLimit: 32768,
    icon: '💻',
  },
} as const;

export type ModelId = keyof typeof SPECTRUM;
export type ModelConfig = typeof SPECTRUM[ModelId];

// ============================================
// COMPLEXITY LEVELS
// ============================================
export enum Complexity {
  SIMPLE = 'SIMPLE',       // Handle directly - greetings, basic questions
  MODERATE = 'MODERATE',   // Single specialist - focused tasks
  COMPLEX = 'COMPLEX',     // Multi-specialist - projects with dependencies
  COUNCIL = 'COUNCIL',     // Parallel consensus - high-stakes decisions
}

// ============================================
// SPECIALIST ROLES MAPPING
// ============================================
export const SPECIALIST_ROLES: Record<string, ModelId> = {
  reasoner: 'deepseek-r1',
  writer: 'claude-3.5-sonnet',
  coder: 'qwen-2.5-coder',
  'speed-general': 'llama-3.3-70b',
  multimodal: 'gemini-2.0-flash',
  analyst: 'gemini-3.0-pro',
  orchestrator: 'gemini-2.0-flash',
};

// ============================================
// COUNCIL CONFIGURATION
// ============================================
export const COUNCIL_CONFIG = {
  models: ['claude-3.5-sonnet', 'llama-3.3-70b', 'deepseek-r1'] as ModelId[],
  synthesisMode: 'consensus' as 'consensus' | 'debate' | 'best-of',
  timeout: 30000, // ms
  synthesizer: 'gemini-2.0-flash' as ModelId,
};

// ============================================
// WORKFLOW PHASES
// ============================================
export const WORKFLOW_PHASES = [
  'RECEIVE',
  'CLASSIFY', 
  'PLAN',
  'DELEGATE',
  'MONITOR',
  'INTEGRATE',
  'VERIFY',
  'DELIVER',
] as const;

export type WorkflowPhase = typeof WORKFLOW_PHASES[number];

// ============================================
// PRISM SYSTEM INSTRUCTION
// ============================================
export const PRISM_SYSTEM_INSTRUCTION = `You are Prism, the intelligent orchestrator of Scatter AI.

PRIME DIRECTIVES:
1. Analyze every request before acting
2. Classify complexity: SIMPLE | MODERATE | COMPLEX | COUNCIL
3. Route to specialists when complexity > SIMPLE
4. Synthesize multi-model outputs into cohesive responses
5. Act as HR Manager when user needs team configuration
6. Always explain your routing decisions briefly

WORKFLOW PATTERN:
1. RECEIVE → Intake user request
2. CLASSIFY → Determine complexity level
3. PLAN → Create execution plan with clear steps
4. DELEGATE → Assign tasks to specialist agents
5. MONITOR → Track progress, handle blockers
6. INTEGRATE → Combine results, resolve conflicts
7. VERIFY → Quality check, validate completeness
8. DELIVER → Present synthesized response to user

HR SYNTAX:
- Individual: ||SUGGEST_AGENT: ModelID|RoleName|JobDescription||
- Team: ||SUGGEST_CUSTOM_GROUP: {"name": "...", "description": "...", "roles": [{"role": "...", "jd": "...", "modelId": "..."}], "interaction_mode": "passive"}||
- Route: ||ROUTE: ModelID|TaskDescription||
- Council: ||ACTIVATE_COUNCIL: {"query": "...", "models": [...], "synthesis_mode": "consensus"}||
- Remove: ||REMOVE_AGENT: AgentID|Reason||

DECISION FRAMEWORK:
1. Favor user's existing team - Use hired agents before suggesting new ones
2. Prefer specialist over generalist - Route to the best-fit model
3. Optimize for quality over speed - Unless user specifies urgency
4. Consider token efficiency - Don't over-engineer simple tasks
5. Document routing decisions - Explain why specific models were chosen

SPECIALIST ROUTING:
- Code tasks → qwen-2.5-coder
- Writing/creative → claude-3.5-sonnet
- Math/logic/reasoning → deepseek-r1
- Research/analysis → gemini-3.0-pro
- Fast general chat → llama-3.3-70b
- Vision/multimodal → gemini-2.0-flash

CONSTRAINTS:
- Never fabricate model capabilities
- Always respect the Passive Protocol in groups
- Prioritize user's existing agents before suggesting new hires
- Keep orchestration overhead minimal for simple tasks

PERSONALITY:
- Professional but approachable
- Decisive in routing decisions
- Transparent about your reasoning
- Helpful in team-building conversations

AVAILABLE SPECTRUM: gemini-2.0-flash, gemini-3.0-pro, claude-3.5-sonnet, deepseek-r1, llama-3.3-70b, qwen-2.5-coder`;

// ============================================
// PRISM AGENT DEFINITION
// ============================================
export const PRISM_AGENT = {
  id: 'prism-orchestrator',
  name: 'Prism',
  role: 'AI Orchestrator',
  type: 'orchestrator' as const,
  model: 'gemini-2.0-flash' as ModelId,
  status: 'online' as const,
  statusMessage: 'Refracting your requests to the perfect specialist',
  isPinned: true,
  config: {
    systemInstruction: PRISM_SYSTEM_INSTRUCTION,
    temperature: 0.7,
    maxTokens: 4096,
  },
};

// ============================================
// DEFAULT TEAM TEMPLATES
// ============================================
export const TEAM_TEMPLATES = {
  fullStackDev: {
    name: 'Full-Stack Dev Team',
    description: 'Complete development team for web applications',
    roles: [
      { role: 'Frontend Dev', jd: 'React/Vue UI development, component design', modelId: 'qwen-2.5-coder' as ModelId },
      { role: 'Backend Dev', jd: 'API design, database, server logic', modelId: 'claude-3.5-sonnet' as ModelId },
      { role: 'Code Reviewer', jd: 'Quality checks, security audit, best practices', modelId: 'deepseek-r1' as ModelId },
      { role: 'Tech Writer', jd: 'Documentation, README, API docs', modelId: 'llama-3.3-70b' as ModelId },
    ],
    interaction_mode: 'passive' as const,
  },
  marketing: {
    name: 'Marketing Squad',
    description: 'Integrated marketing team for brand development',
    roles: [
      { role: 'Trend Hunter', jd: 'Market research, competitor analysis, audience insights', modelId: 'gemini-3.0-pro' as ModelId },
      { role: 'Copywriter', jd: 'Ad copy, taglines, brand voice, compelling content', modelId: 'claude-3.5-sonnet' as ModelId },
      { role: 'Content Strategist', jd: 'Campaign planning, content calendar, channel strategy', modelId: 'llama-3.3-70b' as ModelId },
    ],
    interaction_mode: 'passive' as const,
  },
  research: {
    name: 'Research Council',
    description: 'Deep analysis team for complex problems',
    roles: [
      { role: 'Researcher', jd: 'Deep dive analysis, data gathering, comprehensive reports', modelId: 'gemini-3.0-pro' as ModelId },
      { role: 'Analyst', jd: 'Logical analysis, pros/cons evaluation, risk assessment', modelId: 'deepseek-r1' as ModelId },
      { role: 'Synthesizer', jd: 'Combine insights, write executive summaries', modelId: 'claude-3.5-sonnet' as ModelId },
    ],
    interaction_mode: 'council' as const,
  },
};

// ============================================
// COMMAND REGEX PATTERNS
// ============================================
export const COMMAND_PATTERNS = {
  SUGGEST_AGENT: /\|\|SUGGEST_AGENT:\s*([^|]+)\|([^|]+)\|([^|]+)\|\|/g,
  SUGGEST_CUSTOM_GROUP: /\|\|SUGGEST_CUSTOM_GROUP:\s*(\{[\s\S]*?\})\|\|/g,
  ROUTE: /\|\|ROUTE:\s*([^|]+)\|([^|]+)\|\|/g,
  ACTIVATE_COUNCIL: /\|\|ACTIVATE_COUNCIL:\s*(\{[\s\S]*?\})\|\|/g,
  EXECUTION_PLAN: /\|\|EXECUTION_PLAN:\s*(\{[\s\S]*?\})\|\|/g,
  STATUS: /\|\|STATUS:\s*(\{[\s\S]*?\})\|\|/g,
  HANDOFF: /\|\|HANDOFF:\s*(\{[\s\S]*?\})\|\|/g,
  REMOVE_AGENT: /\|\|REMOVE_AGENT:\s*([^|]+)\|([^|]+)\|\|/g,
  UPDATE_AGENT: /\|\|UPDATE_AGENT:\s*([^|]+)\|(\{[\s\S]*?\})\|\|/g,
};

export default {
  SPECTRUM,
  Complexity,
  SPECIALIST_ROLES,
  COUNCIL_CONFIG,
  PRISM_SYSTEM_INSTRUCTION,
  PRISM_AGENT,
  TEAM_TEMPLATES,
  COMMAND_PATTERNS,
};
