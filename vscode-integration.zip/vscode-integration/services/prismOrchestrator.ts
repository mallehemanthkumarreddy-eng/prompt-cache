// services/prismOrchestrator.ts
// PRISM v2.0 - Spectral Orchestration Engine for Scatter AI

import { SPECTRUM, ModelId, Complexity, COUNCIL_CONFIG, SPECIALIST_ROLES } from '../constants/prismConfig';

// ============================================
// TYPES
// ============================================
export interface ExecutionPlan {
  complexity: Complexity;
  subtasks: Subtask[];
  parallelizable?: number[];
  estimated_tokens?: number;
}

export interface Subtask {
  id: number;
  task: string;
  specialist: ModelId;
  blocking?: number[];
  status?: 'pending' | 'in-progress' | 'complete' | 'failed';
  result?: string;
}

export interface AgentSuggestion {
  modelId: ModelId;
  roleName: string;
  jobDescription: string;
}

export interface TeamSuggestion {
  name: string;
  description: string;
  roles: {
    role: string;
    jd: string;
    modelId: ModelId;
  }[];
  interaction_mode: 'passive' | 'round-robin' | 'council';
}

export interface CouncilResult {
  query: string;
  responses: { model: ModelId; response: string }[];
  synthesis: string;
  mode: 'consensus' | 'debate' | 'best-of';
}

export interface PrismStatus {
  phase: 'RECEIVE' | 'CLASSIFY' | 'PLAN' | 'DELEGATE' | 'MONITOR' | 'INTEGRATE' | 'VERIFY' | 'DELIVER';
  progress: string;
  current: string;
  blockers: string[];
}

// ============================================
// COMPLEXITY CLASSIFIER
// ============================================
export function classifyComplexity(message: string): Complexity {
  const wordCount = message.split(/\s+/).length;
  const hasMultipleTasks = /and|then|also|after|finally|first|second|third/i.test(message);
  const needsReasoning = /why|how|explain|analyze|compare|evaluate|should/i.test(message);
  const isCodeRequest = /code|function|api|implement|build|create.*app|debug|refactor/i.test(message);
  const isSimpleGreeting = /^(hi|hello|hey|thanks|ok|yes|no|sure|good|great)[\s!?.]*$/i.test(message);
  const isHRRequest = /hire|fire|team|agent|specialist|expert/i.test(message);
  const needsMultiplePerspectives = /pros.*cons|compare|versus|vs|debate|opinions/i.test(message);

  // Simple: greetings, short questions, basic HR
  if (isSimpleGreeting || wordCount < 5) return Complexity.SIMPLE;
  
  // Council: needs multiple perspectives or high-stakes decisions
  if (needsMultiplePerspectives || (needsReasoning && hasMultipleTasks && wordCount > 30)) {
    return Complexity.COUNCIL;
  }
  
  // Complex: multi-step tasks, code projects with multiple files
  if ((hasMultipleTasks && isCodeRequest) || (isCodeRequest && wordCount > 50)) {
    return Complexity.COMPLEX;
  }
  
  // Moderate: single specialist tasks
  if (isCodeRequest || needsReasoning || isHRRequest) {
    return Complexity.MODERATE;
  }
  
  return Complexity.SIMPLE;
}

// ============================================
// SPECIALIST ROUTER
// ============================================
export function getSpecialistForTask(taskDescription: string): ModelId {
  const task = taskDescription.toLowerCase();
  
  const taskMappings: { keywords: string[]; model: ModelId }[] = [
    { keywords: ['code', 'coding', 'debug', 'function', 'script', 'program', 'syntax', 'refactor'], model: 'qwen-2.5-coder' },
    { keywords: ['write', 'writing', 'creative', 'story', 'blog', 'article', 'copy', 'nuance'], model: 'claude-3.5-sonnet' },
    { keywords: ['reason', 'math', 'logic', 'calculate', 'proof', 'solve', 'chain-of-thought'], model: 'deepseek-r1' },
    { keywords: ['analyze', 'research', 'deep', 'complex', 'comprehensive', 'long'], model: 'gemini-3.0-pro' },
    { keywords: ['fast', 'quick', 'summary', 'brief', 'chat', 'general'], model: 'llama-3.3-70b' },
    { keywords: ['image', 'vision', 'multimodal', 'picture', 'photo', 'visual'], model: 'gemini-2.0-flash' },
  ];

  for (const mapping of taskMappings) {
    if (mapping.keywords.some(keyword => task.includes(keyword))) {
      return mapping.model;
    }
  }
  
  return 'llama-3.3-70b'; // Default fallback
}

// ============================================
// EXECUTION PLAN BUILDER
// ============================================
export function buildExecutionPlan(message: string, complexity: Complexity): ExecutionPlan | null {
  if (complexity === Complexity.SIMPLE) return null;

  const subtasks: Subtask[] = [];
  const task = message.toLowerCase();

  // Detect task types and build subtasks
  if (task.includes('api') || task.includes('backend')) {
    subtasks.push({ id: 1, task: 'Design API architecture', specialist: 'claude-3.5-sonnet', blocking: [] });
    subtasks.push({ id: 2, task: 'Implement API code', specialist: 'qwen-2.5-coder', blocking: [1] });
  }
  
  if (task.includes('frontend') || task.includes('ui')) {
    const lastId = subtasks.length;
    subtasks.push({ id: lastId + 1, task: 'Design UI components', specialist: 'claude-3.5-sonnet', blocking: [] });
    subtasks.push({ id: lastId + 2, task: 'Implement frontend code', specialist: 'qwen-2.5-coder', blocking: [lastId + 1] });
  }
  
  if (task.includes('document') || task.includes('readme') || task.includes('docs')) {
    const lastId = subtasks.length;
    subtasks.push({ id: lastId + 1, task: 'Write documentation', specialist: 'llama-3.3-70b', blocking: subtasks.map(s => s.id) });
  }
  
  if (task.includes('test') || task.includes('quality')) {
    const lastId = subtasks.length;
    subtasks.push({ id: lastId + 1, task: 'Create test strategy', specialist: 'deepseek-r1', blocking: subtasks.filter(s => s.task.includes('code')).map(s => s.id) });
  }

  // If no specific subtasks detected, create generic ones
  if (subtasks.length === 0) {
    subtasks.push({ id: 1, task: 'Analyze requirements', specialist: 'gemini-3.0-pro', blocking: [] });
    subtasks.push({ id: 2, task: 'Execute primary task', specialist: getSpecialistForTask(message), blocking: [1] });
    subtasks.push({ id: 3, task: 'Review and synthesize', specialist: 'claude-3.5-sonnet', blocking: [2] });
  }

  // Find parallelizable tasks (no blocking dependencies on each other)
  const parallelizable = subtasks
    .filter(s => s.blocking?.length === 0)
    .map(s => s.id);

  return {
    complexity,
    subtasks,
    parallelizable: parallelizable.length > 1 ? parallelizable : undefined,
    estimated_tokens: subtasks.length * 2000,
  };
}

// ============================================
// THE COUNCIL
// ============================================
export async function activateCouncil(
  query: string,
  invokeModel: (modelId: ModelId, prompt: string) => Promise<string>,
  synthesisMode: 'consensus' | 'debate' | 'best-of' = 'consensus'
): Promise<CouncilResult> {
  const councilModels = COUNCIL_CONFIG.models;
  
  // Parallel execution
  const responsePromises = councilModels.map(async (model) => {
    const response = await invokeModel(model, query);
    return { model, response };
  });

  const responses = await Promise.all(responsePromises);

  // Synthesize based on mode
  let synthesisPrompt = '';
  
  switch (synthesisMode) {
    case 'consensus':
      synthesisPrompt = `You are Prism synthesizing council responses. Find common ground and create a unified answer.
      
Query: ${query}

Council Responses:
${responses.map(r => `[${r.model}]: ${r.response}`).join('\n\n')}

Synthesize a single, balanced response that captures the best insights from all perspectives.`;
      break;
      
    case 'debate':
      synthesisPrompt = `You are Prism presenting a balanced debate. Show each perspective clearly.
      
Query: ${query}

Council Responses:
${responses.map(r => `[${r.model}]: ${r.response}`).join('\n\n')}

Present each perspective with its pros and cons, then offer a balanced conclusion.`;
      break;
      
    case 'best-of':
      synthesisPrompt = `You are Prism selecting and enhancing the best response.
      
Query: ${query}

Council Responses:
${responses.map(r => `[${r.model}]: ${r.response}`).join('\n\n')}

Select the strongest response and enhance it with insights from the others.`;
      break;
  }

  // Use orchestrator model for synthesis
  const synthesis = await invokeModel('gemini-2.0-flash', synthesisPrompt);

  return {
    query,
    responses,
    synthesis,
    mode: synthesisMode,
  };
}

// ============================================
// COMMAND PARSERS
// ============================================
const COMMAND_PATTERNS = {
  SUGGEST_AGENT: /\|\|SUGGEST_AGENT:\s*([^|]+)\|([^|]+)\|([^|]+)\|\|/,
  SUGGEST_CUSTOM_GROUP: /\|\|SUGGEST_CUSTOM_GROUP:\s*(\{[\s\S]*?\})\|\|/,
  ROUTE: /\|\|ROUTE:\s*([^|]+)\|([^|]+)\|\|/,
  ACTIVATE_COUNCIL: /\|\|ACTIVATE_COUNCIL:\s*(\{[\s\S]*?\})\|\|/,
  EXECUTION_PLAN: /\|\|EXECUTION_PLAN:\s*(\{[\s\S]*?\})\|\|/,
  STATUS: /\|\|STATUS:\s*(\{[\s\S]*?\})\|\|/,
  REMOVE_AGENT: /\|\|REMOVE_AGENT:\s*([^|]+)\|([^|]+)\|\|/,
};

export function parseAgentSuggestion(text: string): AgentSuggestion | null {
  const match = text.match(COMMAND_PATTERNS.SUGGEST_AGENT);
  if (!match) return null;
  return {
    modelId: match[1].trim() as ModelId,
    roleName: match[2].trim(),
    jobDescription: match[3].trim(),
  };
}

export function parseTeamSuggestion(text: string): TeamSuggestion | null {
  const match = text.match(COMMAND_PATTERNS.SUGGEST_CUSTOM_GROUP);
  if (!match) return null;
  try {
    return JSON.parse(match[1]);
  } catch {
    return null;
  }
}

export function parseRoute(text: string): { modelId: ModelId; task: string } | null {
  const match = text.match(COMMAND_PATTERNS.ROUTE);
  if (!match) return null;
  return {
    modelId: match[1].trim() as ModelId,
    task: match[2].trim(),
  };
}

// ============================================
// MAIN ORCHESTRATOR CLASS
// ============================================
export class PrismOrchestrator {
  private status: PrismStatus = {
    phase: 'RECEIVE',
    progress: '0/0',
    current: 'Idle',
    blockers: [],
  };

  private onStatusChange?: (status: PrismStatus) => void;

  constructor(onStatusChange?: (status: PrismStatus) => void) {
    this.onStatusChange = onStatusChange;
  }

  private updateStatus(updates: Partial<PrismStatus>) {
    this.status = { ...this.status, ...updates };
    this.onStatusChange?.(this.status);
  }

  async orchestrate(
    message: string,
    invokeModel: (modelId: ModelId, prompt: string) => Promise<string>,
    existingAgents: ModelId[] = []
  ): Promise<string> {
    // Phase 1: RECEIVE
    this.updateStatus({ phase: 'RECEIVE', current: 'Analyzing request...' });

    // Phase 2: CLASSIFY
    this.updateStatus({ phase: 'CLASSIFY', current: 'Determining complexity...' });
    const complexity = classifyComplexity(message);

    // Phase 3: Handle based on complexity
    switch (complexity) {
      case Complexity.SIMPLE:
        return this.handleSimple(message, invokeModel);
      
      case Complexity.MODERATE:
        return this.handleModerate(message, invokeModel, existingAgents);
      
      case Complexity.COMPLEX:
        return this.handleComplex(message, invokeModel, existingAgents);
      
      case Complexity.COUNCIL:
        return this.handleCouncil(message, invokeModel);
      
      default:
        return this.handleSimple(message, invokeModel);
    }
  }

  private async handleSimple(
    message: string,
    invokeModel: (modelId: ModelId, prompt: string) => Promise<string>
  ): Promise<string> {
    this.updateStatus({ phase: 'DELIVER', current: 'Responding directly...' });
    return invokeModel('gemini-2.0-flash', message);
  }

  private async handleModerate(
    message: string,
    invokeModel: (modelId: ModelId, prompt: string) => Promise<string>,
    existingAgents: ModelId[]
  ): Promise<string> {
    this.updateStatus({ phase: 'DELEGATE', current: 'Routing to specialist...' });
    
    const specialist = getSpecialistForTask(message);
    
    // Prefer existing agents if available
    const targetModel = existingAgents.includes(specialist) ? specialist : specialist;
    
    this.updateStatus({ phase: 'MONITOR', current: `Awaiting ${targetModel}...` });
    const response = await invokeModel(targetModel, message);
    
    this.updateStatus({ phase: 'DELIVER', current: 'Complete' });
    return response;
  }

  private async handleComplex(
    message: string,
    invokeModel: (modelId: ModelId, prompt: string) => Promise<string>,
    existingAgents: ModelId[]
  ): Promise<string> {
    // Phase 3: PLAN
    this.updateStatus({ phase: 'PLAN', current: 'Creating execution plan...' });
    const plan = buildExecutionPlan(message, Complexity.COMPLEX);
    
    if (!plan) {
      return this.handleModerate(message, invokeModel, existingAgents);
    }

    const results: Map<number, string> = new Map();

    // Phase 4: DELEGATE & MONITOR
    for (const subtask of plan.subtasks) {
      // Check if blocking tasks are complete
      const blockers = subtask.blocking?.filter(id => !results.has(id)) || [];
      if (blockers.length > 0) {
        this.updateStatus({ blockers: blockers.map(id => `Task ${id}`) });
        // Wait would happen here in real implementation
      }

      this.updateStatus({
        phase: 'DELEGATE',
        progress: `${results.size}/${plan.subtasks.length}`,
        current: `Executing: ${subtask.task}`,
        blockers: [],
      });

      const context = subtask.blocking
        ?.map(id => results.get(id))
        .filter(Boolean)
        .join('\n\n') || '';

      const prompt = context
        ? `Context from previous tasks:\n${context}\n\nNew task: ${subtask.task}\n\nOriginal request: ${message}`
        : `Task: ${subtask.task}\n\nOriginal request: ${message}`;

      const result = await invokeModel(subtask.specialist, prompt);
      results.set(subtask.id, result);
    }

    // Phase 5: INTEGRATE
    this.updateStatus({ phase: 'INTEGRATE', current: 'Synthesizing results...' });
    
    const allResults = Array.from(results.values()).join('\n\n---\n\n');
    const synthesisPrompt = `You are Prism synthesizing multiple specialist outputs into a cohesive response.

Original request: ${message}

Specialist outputs:
${allResults}

Create a unified, well-organized response that combines all insights.`;

    const synthesis = await invokeModel('claude-3.5-sonnet', synthesisPrompt);

    // Phase 6: VERIFY & DELIVER
    this.updateStatus({ phase: 'VERIFY', current: 'Quality check...' });
    this.updateStatus({ phase: 'DELIVER', current: 'Complete' });

    return synthesis;
  }

  private async handleCouncil(
    message: string,
    invokeModel: (modelId: ModelId, prompt: string) => Promise<string>
  ): Promise<string> {
    this.updateStatus({ phase: 'DELEGATE', current: 'Activating The Council...' });
    
    const result = await activateCouncil(message, invokeModel, 'consensus');
    
    this.updateStatus({ phase: 'INTEGRATE', current: 'Synthesizing council responses...' });
    this.updateStatus({ phase: 'DELIVER', current: 'Complete' });
    
    return result.synthesis;
  }

  getStatus(): PrismStatus {
    return { ...this.status };
  }
}

export default PrismOrchestrator;
