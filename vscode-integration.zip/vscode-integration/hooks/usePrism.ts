// hooks/usePrism.ts
// React hook for integrating Prism Orchestrator into Scatter AI

import { useState, useCallback, useRef } from 'react';
import PrismOrchestrator, {
  PrismStatus,
  ExecutionPlan,
  AgentSuggestion,
  TeamSuggestion,
  parseAgentSuggestion,
  parseTeamSuggestion,
  classifyComplexity,
  buildExecutionPlan,
} from '../services/prismOrchestrator';
import { ModelId, Complexity, PRISM_SYSTEM_INSTRUCTION } from '../constants/prismConfig';

// ============================================
// TYPES
// ============================================
interface UsePrismOptions {
  onStatusChange?: (status: PrismStatus) => void;
  onAgentSuggested?: (suggestion: AgentSuggestion) => void;
  onTeamSuggested?: (suggestion: TeamSuggestion) => void;
  onRouteDecision?: (modelId: ModelId, task: string) => void;
}

interface PrismState {
  isProcessing: boolean;
  currentPhase: PrismStatus['phase'];
  progress: string;
  complexity: Complexity | null;
  executionPlan: ExecutionPlan | null;
  lastSuggestion: AgentSuggestion | TeamSuggestion | null;
  error: string | null;
}

interface UsePrismReturn {
  state: PrismState;
  orchestrate: (message: string, existingAgents?: ModelId[]) => Promise<string>;
  analyzeOnly: (message: string) => { complexity: Complexity; plan: ExecutionPlan | null };
  suggestAgent: (request: string) => Promise<AgentSuggestion | null>;
  suggestTeam: (request: string) => Promise<TeamSuggestion | null>;
  reset: () => void;
}

// ============================================
// HOOK IMPLEMENTATION
// ============================================
export function usePrism(
  invokeModel: (modelId: ModelId, prompt: string) => Promise<string>,
  options: UsePrismOptions = {}
): UsePrismReturn {
  const { onStatusChange, onAgentSuggested, onTeamSuggested, onRouteDecision } = options;

  const [state, setState] = useState<PrismState>({
    isProcessing: false,
    currentPhase: 'RECEIVE',
    progress: '0/0',
    complexity: null,
    executionPlan: null,
    lastSuggestion: null,
    error: null,
  });

  const orchestratorRef = useRef<PrismOrchestrator | null>(null);

  // Initialize orchestrator with status callback
  const getOrchestrator = useCallback(() => {
    if (!orchestratorRef.current) {
      orchestratorRef.current = new PrismOrchestrator((status) => {
        setState((prev) => ({
          ...prev,
          currentPhase: status.phase,
          progress: status.progress,
        }));
        onStatusChange?.(status);
      });
    }
    return orchestratorRef.current;
  }, [onStatusChange]);

  // Main orchestration function
  const orchestrate = useCallback(
    async (message: string, existingAgents: ModelId[] = []): Promise<string> => {
      setState((prev) => ({
        ...prev,
        isProcessing: true,
        error: null,
        complexity: null,
        executionPlan: null,
      }));

      try {
        // Classify complexity
        const complexity = classifyComplexity(message);
        const plan = buildExecutionPlan(message, complexity);

        setState((prev) => ({
          ...prev,
          complexity,
          executionPlan: plan,
        }));

        // Check for HR requests first
        if (isHRRequest(message)) {
          return await handleHRRequest(message, invokeModel, {
            onAgentSuggested: (suggestion) => {
              setState((prev) => ({ ...prev, lastSuggestion: suggestion }));
              onAgentSuggested?.(suggestion);
            },
            onTeamSuggested: (suggestion) => {
              setState((prev) => ({ ...prev, lastSuggestion: suggestion }));
              onTeamSuggested?.(suggestion);
            },
          });
        }

        // Use orchestrator for other requests
        const orchestrator = getOrchestrator();
        const response = await orchestrator.orchestrate(message, invokeModel, existingAgents);

        // Check response for embedded commands
        const agentSuggestion = parseAgentSuggestion(response);
        if (agentSuggestion) {
          setState((prev) => ({ ...prev, lastSuggestion: agentSuggestion }));
          onAgentSuggested?.(agentSuggestion);
        }

        const teamSuggestion = parseTeamSuggestion(response);
        if (teamSuggestion) {
          setState((prev) => ({ ...prev, lastSuggestion: teamSuggestion }));
          onTeamSuggested?.(teamSuggestion);
        }

        return response;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setState((prev) => ({ ...prev, error: errorMessage }));
        throw error;
      } finally {
        setState((prev) => ({ ...prev, isProcessing: false }));
      }
    },
    [invokeModel, getOrchestrator, onAgentSuggested, onTeamSuggested]
  );

  // Analyze without executing
  const analyzeOnly = useCallback((message: string) => {
    const complexity = classifyComplexity(message);
    const plan = buildExecutionPlan(message, complexity);
    return { complexity, plan };
  }, []);

  // Suggest a single agent
  const suggestAgent = useCallback(
    async (request: string): Promise<AgentSuggestion | null> => {
      const prompt = `${PRISM_SYSTEM_INSTRUCTION}

User request: "${request}"

Based on this request, suggest a single specialist agent. Use the exact format:
||SUGGEST_AGENT: ModelID|RoleName|JobDescription||

Available models: gemini-2.0-flash, gemini-3.0-pro, claude-3.5-sonnet, deepseek-r1, llama-3.3-70b, qwen-2.5-coder`;

      const response = await invokeModel('gemini-2.0-flash', prompt);
      const suggestion = parseAgentSuggestion(response);
      
      if (suggestion) {
        setState((prev) => ({ ...prev, lastSuggestion: suggestion }));
        onAgentSuggested?.(suggestion);
      }
      
      return suggestion;
    },
    [invokeModel, onAgentSuggested]
  );

  // Suggest a team
  const suggestTeam = useCallback(
    async (request: string): Promise<TeamSuggestion | null> => {
      const prompt = `${PRISM_SYSTEM_INSTRUCTION}

User request: "${request}"

Based on this request, suggest a complete team. Use the exact format:
||SUGGEST_CUSTOM_GROUP: {"name": "Team Name", "description": "Team purpose", "roles": [{"role": "Role Title", "jd": "Job description", "modelId": "model-id"}], "interaction_mode": "passive"}||

Available models: gemini-2.0-flash, gemini-3.0-pro, claude-3.5-sonnet, deepseek-r1, llama-3.3-70b, qwen-2.5-coder`;

      const response = await invokeModel('gemini-2.0-flash', prompt);
      const suggestion = parseTeamSuggestion(response);
      
      if (suggestion) {
        setState((prev) => ({ ...prev, lastSuggestion: suggestion }));
        onTeamSuggested?.(suggestion);
      }
      
      return suggestion;
    },
    [invokeModel, onTeamSuggested]
  );

  // Reset state
  const reset = useCallback(() => {
    setState({
      isProcessing: false,
      currentPhase: 'RECEIVE',
      progress: '0/0',
      complexity: null,
      executionPlan: null,
      lastSuggestion: null,
      error: null,
    });
    orchestratorRef.current = null;
  }, []);

  return {
    state,
    orchestrate,
    analyzeOnly,
    suggestAgent,
    suggestTeam,
    reset,
  };
}

// ============================================
// HELPER FUNCTIONS
// ============================================
function isHRRequest(message: string): boolean {
  const hrKeywords = /hire|fire|team|group|agent|specialist|expert|create.*team|build.*team|assemble/i;
  return hrKeywords.test(message);
}

interface HRHandlerOptions {
  onAgentSuggested?: (suggestion: AgentSuggestion) => void;
  onTeamSuggested?: (suggestion: TeamSuggestion) => void;
}

async function handleHRRequest(
  message: string,
  invokeModel: (modelId: ModelId, prompt: string) => Promise<string>,
  options: HRHandlerOptions
): Promise<string> {
  const isTeamRequest = /team|group|squad|crew|assemble/i.test(message);
  
  const prompt = `${PRISM_SYSTEM_INSTRUCTION}

User request: "${message}"

${isTeamRequest 
  ? 'Suggest a complete team with multiple specialists using ||SUGGEST_CUSTOM_GROUP: {...}|| format.'
  : 'Suggest a single specialist agent using ||SUGGEST_AGENT: ModelID|RoleName|JobDescription|| format.'}

Also provide a brief, friendly explanation of your suggestion.`;

  const response = await invokeModel('gemini-2.0-flash', prompt);

  // Parse and callback
  const agentSuggestion = parseAgentSuggestion(response);
  if (agentSuggestion) {
    options.onAgentSuggested?.(agentSuggestion);
  }

  const teamSuggestion = parseTeamSuggestion(response);
  if (teamSuggestion) {
    options.onTeamSuggested?.(teamSuggestion);
  }

  return response;
}

export default usePrism;
