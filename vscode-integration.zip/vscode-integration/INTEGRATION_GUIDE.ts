// INTEGRATION EXAMPLE: How to integrate Prism v2.0 into your existing useScatter hook
// File: hooks/useScatter.ts (modifications)

/*
=============================================================================
PRISM v2.0 INTEGRATION GUIDE FOR SCATTER AI
=============================================================================

This file shows how to integrate the enhanced Prism orchestrator into your
existing useScatter.ts hook. Copy the relevant sections into your codebase.

=============================================================================
*/

import { useState, useCallback } from 'react';
import { usePrism } from './usePrism';
import { ModelId, Complexity, PRISM_AGENT } from '../constants/prismConfig';
import { PrismStatus, AgentSuggestion, TeamSuggestion } from '../services/prismOrchestrator';

// ============================================
// STEP 1: Add Prism State to your existing state
// ============================================
interface ScatterState {
  // ... your existing state
  
  // NEW: Prism orchestration state
  prismStatus: PrismStatus | null;
  prismComplexity: Complexity | null;
  pendingSuggestion: AgentSuggestion | TeamSuggestion | null;
  isOrchestrating: boolean;
}

// ============================================
// STEP 2: Modify handleSendMessage
// ============================================
export function useScatter() {
  // Your existing state...
  const [agents, setAgents] = useState<Agent[]>([]);
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  
  // NEW: Prism state
  const [prismStatus, setPrismStatus] = useState<PrismStatus | null>(null);
  const [pendingSuggestion, setPendingSuggestion] = useState<AgentSuggestion | TeamSuggestion | null>(null);

  // Your existing invokeModel function
  const invokeModel = useCallback(async (modelId: ModelId, prompt: string): Promise<string> => {
    // Your existing AWS Bedrock / API call logic here
    // Example:
    // const response = await bedrockService.invoke(modelId, prompt);
    // return response;
    return ''; // Placeholder
  }, []);

  // NEW: Initialize Prism hook
  const prism = usePrism(invokeModel, {
    onStatusChange: (status) => {
      setPrismStatus(status);
    },
    onAgentSuggested: (suggestion) => {
      setPendingSuggestion(suggestion);
      // Optionally auto-show hiring modal
    },
    onTeamSuggested: (suggestion) => {
      setPendingSuggestion(suggestion);
      // Optionally auto-show team creation modal
    },
  });

  // NEW: Enhanced message handler with Prism orchestration
  const handleSendMessage = useCallback(async (content: string) => {
    // Add user message to chat
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMessage]);

    // Check if talking to Prism
    const isPrismChat = activeChat === PRISM_AGENT.id;
    
    if (isPrismChat) {
      // Use Prism orchestration
      try {
        const existingAgentModels = agents.map((a) => a.model as ModelId);
        const response = await prism.orchestrate(content, existingAgentModels);
        
        // Add Prism response
        const prismMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: response,
          timestamp: new Date(),
          agentId: PRISM_AGENT.id,
          metadata: {
            complexity: prism.state.complexity,
            orchestrated: true,
          },
        };
        setMessages((prev) => [...prev, prismMessage]);
      } catch (error) {
        console.error('Prism orchestration error:', error);
        // Handle error...
      }
    } else {
      // Direct chat with specific agent (your existing logic)
      const agent = agents.find((a) => a.id === activeChat);
      if (agent) {
        const response = await invokeModel(agent.model as ModelId, content);
        // Add response message...
      }
    }
  }, [activeChat, agents, invokeModel, prism]);

  // NEW: Accept suggestion helper
  const acceptSuggestion = useCallback(() => {
    if (!pendingSuggestion) return;

    if ('modelId' in pendingSuggestion && 'roleName' in pendingSuggestion) {
      // It's an AgentSuggestion
      const newAgent: Agent = {
        id: Date.now().toString(),
        name: pendingSuggestion.roleName,
        role: pendingSuggestion.roleName,
        model: pendingSuggestion.modelId,
        systemInstruction: `You are a ${pendingSuggestion.roleName}. ${pendingSuggestion.jobDescription}`,
        // ... other agent properties
      };
      setAgents((prev) => [...prev, newAgent]);
    } else if ('roles' in pendingSuggestion) {
      // It's a TeamSuggestion
      const newGroup: Group = {
        id: Date.now().toString(),
        name: pendingSuggestion.name,
        description: pendingSuggestion.description,
        members: pendingSuggestion.roles.map((role, index) => ({
          id: `${Date.now()}-${index}`,
          name: role.role,
          role: role.role,
          model: role.modelId,
          systemInstruction: role.jd,
        })),
        interactionMode: pendingSuggestion.interaction_mode,
      };
      // Add group to state...
    }

    setPendingSuggestion(null);
  }, [pendingSuggestion]);

  // NEW: Reject suggestion helper
  const rejectSuggestion = useCallback(() => {
    setPendingSuggestion(null);
  }, []);

  // NEW: Quick analyze (without executing)
  const analyzeMessage = useCallback((content: string) => {
    return prism.analyzeOnly(content);
  }, [prism]);

  return {
    // Your existing returns...
    agents,
    activeChat,
    messages,
    handleSendMessage,
    
    // NEW: Prism-specific returns
    prismStatus,
    prismState: prism.state,
    pendingSuggestion,
    acceptSuggestion,
    rejectSuggestion,
    analyzeMessage,
    isOrchestrating: prism.state.isProcessing,
  };
}

// ============================================
// STEP 3: Update your types (types.ts)
// ============================================
/*
Add to your types.ts:

interface Message {
  // ... existing fields
  metadata?: {
    complexity?: Complexity;
    orchestrated?: boolean;
    executionPlan?: ExecutionPlan;
  };
}

interface Agent {
  // ... existing fields
  model: ModelId;
}

interface Group {
  // ... existing fields
  interactionMode?: 'passive' | 'round-robin' | 'council';
}
*/

// ============================================
// STEP 4: Update your InputBar component
// ============================================
/*
In components/InputBar.tsx, add complexity preview:

import { analyzeMessage } from '../hooks/useScatter';

// In the component:
const [preview, setPreview] = useState<{ complexity: Complexity } | null>(null);

const handleInputChange = (value: string) => {
  setInput(value);
  // Show complexity preview as user types
  if (value.length > 10) {
    const analysis = analyzeMessage(value);
    setPreview(analysis);
  } else {
    setPreview(null);
  }
};

// In JSX, show badge:
{preview && <ComplexityBadge complexity={preview.complexity} size="sm" />}
*/

// ============================================
// STEP 5: Update your ChatView component
// ============================================
/*
In components/ChatView.tsx, add status indicator:

import { PrismStatusIndicator, PrismTypingIndicator } from './PrismStatus';

// In the component:
const { prismStatus, isOrchestrating, prismState } = useScatter();

// In JSX, before message input:
{isOrchestrating && (
  <PrismStatusIndicator 
    status={prismStatus!}
    complexity={prismState.complexity}
    isProcessing={true}
    theme="dark"
  />
)}

// Or use typing indicator for simpler display:
{isOrchestrating && <PrismTypingIndicator phase={prismStatus?.phase} />}
*/

// ============================================
// STEP 6: Add Prism to your agent list
// ============================================
/*
In your initialization or constants:

import { PRISM_AGENT } from '../constants/prismConfig';

// Ensure Prism is always first in the list
const defaultAgents = [
  PRISM_AGENT,
  // ... other default agents
];
*/

export default useScatter;
