# PRISM v2.0 - VS Code Integration Package

## 🌈 Spectral Orchestration Engine for Scatter AI

This package upgrades Prism from a basic "HR Assistant" to a full **Orchestration Engine** inspired by professional multi-agent coordinator patterns.

---

## 📁 File Structure

```
vscode-integration/
├── constants/
│   └── prismConfig.ts      # Configuration, models, system prompts
├── services/
│   └── prismOrchestrator.ts # Core orchestration logic
├── hooks/
│   └── usePrism.ts         # React hook for easy integration
├── components/
│   └── PrismStatus.tsx     # UI components for status display
├── INTEGRATION_GUIDE.ts    # Step-by-step integration instructions
└── README.md               # This file
```

---

## 🚀 Quick Start

### 1. Copy Files to Your Project

```bash
# Copy the entire vscode-integration folder to your Scatter AI project
cp -r vscode-integration/* your-project/src/
```

### 2. Update Imports in Your useScatter.ts

```typescript
import { usePrism } from './hooks/usePrism';
import { ModelId, PRISM_AGENT } from './constants/prismConfig';
```

### 3. Initialize Prism Hook

```typescript
const prism = usePrism(invokeModel, {
  onStatusChange: (status) => console.log('Prism:', status.phase),
  onAgentSuggested: (suggestion) => showHireModal(suggestion),
  onTeamSuggested: (suggestion) => showTeamModal(suggestion),
});
```

### 4. Use in Message Handler

```typescript
const handleSendMessage = async (message: string) => {
  if (activeChat === 'prism-orchestrator') {
    const response = await prism.orchestrate(message, existingAgentModels);
    // Handle response...
  }
};
```

---

## ✨ New Features

### Complexity Classification

| Level | Trigger | Handling |
|-------|---------|----------|
| **SIMPLE** | Greetings, basic questions | Direct response (no overhead) |
| **MODERATE** | Single-focus tasks | Route to best specialist |
| **COMPLEX** | Multi-step projects | Execution plan + synthesis |
| **COUNCIL** | High-stakes decisions | Parallel 3-model consensus |

### Workflow Engine

```
RECEIVE → CLASSIFY → PLAN → DELEGATE → MONITOR → INTEGRATE → VERIFY → DELIVER
```

### The Council

For complex decisions, Prism queries 3 models in parallel:
- **Claude 3.5 Sonnet** - Nuance & Writing
- **Llama 3.3 70B** - Speed & General Knowledge  
- **DeepSeek R1** - Logic & Reasoning

Then synthesizes a unified response.

### Enhanced HR Commands

```
||SUGGEST_AGENT: model-id|Role Name|Job description||
||SUGGEST_CUSTOM_GROUP: {"name": "...", "roles": [...]}||
||ROUTE: model-id|Task description||
||ACTIVATE_COUNCIL: {"query": "...", "synthesis_mode": "consensus"}||
||EXECUTION_PLAN: {"subtasks": [...], "parallelizable": [...]}||
||STATUS: {"phase": "DELEGATE", "progress": "2/4"}||
```

---

## 🎨 UI Components

### PrismStatusIndicator

Shows real-time orchestration progress:

```tsx
<PrismStatusIndicator 
  status={prismStatus}
  complexity={Complexity.COMPLEX}
  isProcessing={true}
  theme="dark"
/>
```

### PrismTypingIndicator

Simple typing indicator with phase:

```tsx
<PrismTypingIndicator phase="DELEGATE" />
```

### ComplexityBadge

Visual badge for complexity level:

```tsx
<ComplexityBadge complexity={Complexity.COUNCIL} size="md" />
```

### CouncilIndicator

Shows active council members:

```tsx
<CouncilIndicator 
  activeModels={['claude-3.5-sonnet', 'llama-3.3-70b', 'deepseek-r1']}
  synthesizing={true}
/>
```

---

## 📋 Configuration

### Available Models (Spectrum)

| Model ID | Provider | Best For |
|----------|----------|----------|
| `gemini-2.0-flash` | Google | Orchestration, Multimodal |
| `gemini-3.0-pro` | Google | Complex Analysis |
| `claude-3.5-sonnet` | Anthropic | Writing, Nuance |
| `deepseek-r1` | DeepSeek | Reasoning, Math |
| `llama-3.3-70b` | Meta (Groq) | Speed, General |
| `qwen-2.5-coder` | Alibaba | Code Generation |

### Customizing System Prompt

Edit `constants/prismConfig.ts`:

```typescript
export const PRISM_SYSTEM_INSTRUCTION = `
  Your custom instructions here...
`;
```

### Team Templates

Pre-built team configurations in `TEAM_TEMPLATES`:
- `fullStackDev` - Complete dev team
- `marketing` - Brand marketing squad
- `research` - Deep analysis council

---

## 🔧 API Reference

### usePrism Hook

```typescript
const {
  state,           // { isProcessing, currentPhase, complexity, executionPlan, error }
  orchestrate,     // (message, existingAgents?) => Promise<string>
  analyzeOnly,     // (message) => { complexity, plan }
  suggestAgent,    // (request) => Promise<AgentSuggestion>
  suggestTeam,     // (request) => Promise<TeamSuggestion>
  reset,           // () => void
} = usePrism(invokeModel, options);
```

### PrismOrchestrator Class

```typescript
const orchestrator = new PrismOrchestrator(onStatusChange);

await orchestrator.orchestrate(
  message,       // User's input
  invokeModel,   // Your model invocation function
  existingAgents // Array of already hired model IDs
);

orchestrator.getStatus(); // Get current status
```

---

## 🎯 Decision Framework

When Prism makes routing decisions, it follows these principles:

1. **Favor existing team** - Use hired agents before suggesting new ones
2. **Prefer specialist** - Route to best-fit model for the task
3. **Optimize quality** - Unless user requests speed
4. **Token efficiency** - Don't over-engineer simple tasks
5. **Document decisions** - Brief explanation of routing choices

---

## 📝 Example Interactions

### Simple (Direct Response)
```
User: "Hi!"
Prism: "Hello! How can I help you today?"
```

### Moderate (Single Specialist)
```
User: "Write a Python function to sort a list"
Prism: [Routes to qwen-2.5-coder]
       "Here's an efficient sorting function..."
```

### Complex (Multi-Specialist)
```
User: "Build a REST API with documentation"
Prism: [Creates execution plan]
       Phase 1: Design (claude-3.5-sonnet)
       Phase 2: Implement (qwen-2.5-coder)  
       Phase 3: Document (llama-3.3-70b)
       [Synthesizes final response]
```

### Council (Parallel Consensus)
```
User: "Should we use microservices or monolith?"
Prism: [Activates Council]
       - Claude: Team dynamics perspective
       - Llama: Quick pros/cons
       - DeepSeek: Cost analysis
       [Synthesizes balanced recommendation]
```

### HR Request
```
User: "Hire a Python expert"
Prism: ||SUGGEST_AGENT: qwen-2.5-coder|Python Expert|Specialized in...||
       "I recommend hiring a Python Expert powered by Qwen 2.5 Coder..."
```

---

## 🛠️ Troubleshooting

### Prism not routing correctly

Check that your `invokeModel` function properly handles all model IDs in the Spectrum.

### Status not updating

Ensure you're passing the `onStatusChange` callback when initializing `usePrism`.

### Suggestions not parsing

Verify the model response includes the exact syntax: `||SUGGEST_AGENT: ...||`

---

## 📄 License

Part of Scatter AI - Spectral Intelligence Platform

---

**Prism v2.0** - *Refracting Intelligence* 🌈
