// components/PrismStatus.tsx
// Visual status indicator for Prism Orchestrator

import React from 'react';
import { PrismStatus as PrismStatusType } from '../services/prismOrchestrator';
import { Complexity, WORKFLOW_PHASES } from '../constants/prismConfig';

interface PrismStatusProps {
  status: PrismStatusType;
  complexity?: Complexity | null;
  isProcessing: boolean;
  theme?: 'dark' | 'light';
}

const PHASE_ICONS: Record<PrismStatusType['phase'], string> = {
  RECEIVE: '📥',
  CLASSIFY: '🔍',
  PLAN: '📋',
  DELEGATE: '🎯',
  MONITOR: '👁️',
  INTEGRATE: '🔗',
  VERIFY: '✅',
  DELIVER: '📤',
};

const COMPLEXITY_COLORS: Record<Complexity, string> = {
  [Complexity.SIMPLE]: 'bg-green-500',
  [Complexity.MODERATE]: 'bg-yellow-500',
  [Complexity.COMPLEX]: 'bg-orange-500',
  [Complexity.COUNCIL]: 'bg-purple-500',
};

const COMPLEXITY_LABELS: Record<Complexity, string> = {
  [Complexity.SIMPLE]: 'Simple',
  [Complexity.MODERATE]: 'Moderate',
  [Complexity.COMPLEX]: 'Complex',
  [Complexity.COUNCIL]: 'Council',
};

export const PrismStatusIndicator: React.FC<PrismStatusProps> = ({
  status,
  complexity,
  isProcessing,
  theme = 'dark',
}) => {
  const bgClass = theme === 'dark' ? 'bg-gray-800' : 'bg-white';
  const textClass = theme === 'dark' ? 'text-white' : 'text-gray-900';
  const subtextClass = theme === 'dark' ? 'text-gray-400' : 'text-gray-600';

  if (!isProcessing) {
    return null;
  }

  return (
    <div className={`${bgClass} ${textClass} rounded-lg p-4 shadow-lg border border-cyan-500/30`}>
      {/* Header */}
      <div className="flex items-center gap-2 mb-3">
        <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
        <span className="text-sm font-semibold text-cyan-400">PRISM ORCHESTRATING</span>
        {complexity && (
          <span className={`px-2 py-0.5 rounded text-xs font-medium text-white ${COMPLEXITY_COLORS[complexity]}`}>
            {COMPLEXITY_LABELS[complexity]}
          </span>
        )}
      </div>

      {/* Progress Bar */}
      <div className="mb-3">
        <div className="flex justify-between text-xs mb-1">
          <span className={subtextClass}>Phase: {status.phase}</span>
          <span className={subtextClass}>{status.progress}</span>
        </div>
        <div className="h-1 bg-gray-700 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 transition-all duration-300"
            style={{
              width: `${(WORKFLOW_PHASES.indexOf(status.phase) + 1) / WORKFLOW_PHASES.length * 100}%`,
            }}
          />
        </div>
      </div>

      {/* Phase Indicators */}
      <div className="flex justify-between mb-3">
        {WORKFLOW_PHASES.map((phase, index) => {
          const currentIndex = WORKFLOW_PHASES.indexOf(status.phase);
          const isActive = index === currentIndex;
          const isComplete = index < currentIndex;
          
          return (
            <div
              key={phase}
              className={`flex flex-col items-center ${
                isActive ? 'text-cyan-400' : isComplete ? 'text-green-400' : subtextClass
              }`}
            >
              <span className="text-lg">{PHASE_ICONS[phase]}</span>
              <span className="text-[10px] mt-1 hidden sm:block">{phase}</span>
            </div>
          );
        })}
      </div>

      {/* Current Action */}
      <div className={`text-sm ${subtextClass}`}>
        <span className="font-medium">Current:</span> {status.current}
      </div>

      {/* Blockers */}
      {status.blockers.length > 0 && (
        <div className="mt-2 p-2 bg-red-500/20 rounded border border-red-500/30">
          <span className="text-red-400 text-xs font-medium">⚠️ Blockers:</span>
          <ul className="text-red-300 text-xs mt-1">
            {status.blockers.map((blocker, i) => (
              <li key={i}>• {blocker}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

// ============================================
// PRISM TYPING INDICATOR
// ============================================
interface PrismTypingProps {
  phase?: PrismStatusType['phase'];
  theme?: 'dark' | 'light';
}

export const PrismTypingIndicator: React.FC<PrismTypingProps> = ({ 
  phase = 'CLASSIFY',
  theme = 'dark' 
}) => {
  const bgClass = theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200';
  const textClass = theme === 'dark' ? 'text-gray-300' : 'text-gray-700';

  return (
    <div className={`flex items-center gap-2 ${textClass} text-sm`}>
      <div className="flex gap-1">
        <div className={`w-2 h-2 rounded-full ${bgClass} animate-bounce`} style={{ animationDelay: '0ms' }} />
        <div className={`w-2 h-2 rounded-full ${bgClass} animate-bounce`} style={{ animationDelay: '150ms' }} />
        <div className={`w-2 h-2 rounded-full ${bgClass} animate-bounce`} style={{ animationDelay: '300ms' }} />
      </div>
      <span className="text-cyan-400">
        {PHASE_ICONS[phase]} Prism is {phase.toLowerCase()}ing...
      </span>
    </div>
  );
};

// ============================================
// COMPLEXITY BADGE
// ============================================
interface ComplexityBadgeProps {
  complexity: Complexity;
  size?: 'sm' | 'md' | 'lg';
}

export const ComplexityBadge: React.FC<ComplexityBadgeProps> = ({ 
  complexity, 
  size = 'md' 
}) => {
  const sizeClasses = {
    sm: 'px-1.5 py-0.5 text-[10px]',
    md: 'px-2 py-1 text-xs',
    lg: 'px-3 py-1.5 text-sm',
  };

  return (
    <span 
      className={`
        ${sizeClasses[size]} 
        ${COMPLEXITY_COLORS[complexity]} 
        text-white font-medium rounded-full
      `}
    >
      {COMPLEXITY_LABELS[complexity]}
    </span>
  );
};

// ============================================
// COUNCIL INDICATOR
// ============================================
interface CouncilIndicatorProps {
  activeModels: string[];
  synthesizing: boolean;
  theme?: 'dark' | 'light';
}

export const CouncilIndicator: React.FC<CouncilIndicatorProps> = ({
  activeModels,
  synthesizing,
  theme = 'dark',
}) => {
  const bgClass = theme === 'dark' ? 'bg-purple-900/30' : 'bg-purple-100';
  const borderClass = 'border-purple-500/50';

  return (
    <div className={`${bgClass} border ${borderClass} rounded-lg p-3`}>
      <div className="flex items-center gap-2 mb-2">
        <span className="text-purple-400 font-semibold text-sm">🏛️ THE COUNCIL</span>
        {synthesizing && (
          <span className="text-xs text-purple-300 animate-pulse">Synthesizing...</span>
        )}
      </div>
      <div className="flex gap-2">
        {activeModels.map((model) => (
          <div
            key={model}
            className="px-2 py-1 bg-purple-800/50 rounded text-xs text-purple-200"
          >
            {model}
          </div>
        ))}
      </div>
    </div>
  );
};

export default PrismStatusIndicator;
